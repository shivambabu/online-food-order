Free Download Source Code "Online Food Ordering System"

FIRST Download

1.XAMPP

2."TEXT EDITOR" NOTEPAD++ OR SUBLIME TEXT 3 / ETC.

3"Online-Food-Order"

4. Download the zip file/ download winrar

5. Extract the file and copy "Online-Food-Order" folder

6.Paste inside root directory/ where you install xammp local disk C: drive D: drive E: paste: (for xampp/htdocs, 

7. Open PHPMyAdmin (http://localhost/phpmyadmin)

8. Create a database with name foodorder

6. Import foodorder.sql file(given inside the zip package in SQL file folder)

7.Run the script http://localhost/Online-Food-Order

admin: Aditi Naik/ aditi   
user: birju/ Birju123@

Subcribe my channel thank You,,,,